package com.first.nearestplacebasegpsmvpandroid.ApiConfig

import com.first.nearestplacebasegpsmvpandroid.utils.Constans
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Retrofit


object ConfigNetwork {

    fun getRetrofit(): Retrofit {
        var retrofit = Retrofit.Builder()
            .baseUrl(Constans.BASE_URL)
            .client(getInterceptor())
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        return retrofit

    }

    fun getInterceptor(): OkHttpClient {
        val logging = HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .build()

        return client
    }

    fun getService(): PlaceApi {
        val service = getRetrofit().create(PlaceApi::class.java!!)
        return service
    }
}