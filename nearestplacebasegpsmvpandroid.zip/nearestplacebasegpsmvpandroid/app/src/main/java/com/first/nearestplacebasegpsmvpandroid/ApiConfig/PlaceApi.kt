package com.first.nearestplacebasegpsmvpandroid.ApiConfig

import com.first.nearestplacebasegpsmvpandroid.model.ResultPlace
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface PlaceApi {
    @GET("nearbysearch/json")
    fun ambilNamaTempatRequest(
        @Query("location") location: String,
        @Query("radius") radius: String,
        @Query("type") type: String,
        @Query("keyword") keyword: String,
        @Query("key") key: String
    ): Call<ResultPlace>
}