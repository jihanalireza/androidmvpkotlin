package com.first.nearestplacebasegpsmvpandroid.model

import javax.annotation.Generated
import com.google.gson.annotations.SerializedName

@Generated("com.robohorse.robopojogenerator")
data class OpeningHours(

	@field:SerializedName("open_now")
	val openNow: Boolean? = null
)