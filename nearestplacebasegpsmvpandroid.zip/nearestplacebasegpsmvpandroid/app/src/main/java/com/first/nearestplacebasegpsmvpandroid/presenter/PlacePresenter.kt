package com.first.nearestplacebasegpsmvpandroid.presenter

import com.first.nearestplacebasegpsmvpandroid.ApiConfig.ConfigNetwork
import com.first.nearestplacebasegpsmvpandroid.model.ResultPlace
import com.first.nearestplacebasegpsmvpandroid.model.ResultsItem
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PlacePresenter(val placeView: PlaceView){
    fun loadData(location: String, keyword: String, type: String, key: String) {
        ConfigNetwork.getService().ambilNamaTempatRequest(location,"5000",type,keyword,key)
            .enqueue(object: Callback<ResultPlace>{
                override fun onFailure(call: Call<ResultPlace>, t: Throwable) {
                    placeView.onError(t.localizedMessage)
                }

                override fun onResponse(call: Call<ResultPlace>, response: Response<ResultPlace>) {

                    if(response.isSuccessful){
                        val data = response.body()?.results
                        placeView.onResult(data as List<ResultsItem>)
                    }
                    else{
                        placeView.onError(response.errorBody().toString())
                    }

                }

            })
    }
}