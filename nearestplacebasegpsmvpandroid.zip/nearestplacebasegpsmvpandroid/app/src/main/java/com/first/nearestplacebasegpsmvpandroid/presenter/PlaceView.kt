package com.first.nearestplacebasegpsmvpandroid.presenter

import com.first.nearestplacebasegpsmvpandroid.model.ResultsItem

interface PlaceView {
    fun onResult(data:List<ResultsItem>)
    fun onError(msg :String)
}