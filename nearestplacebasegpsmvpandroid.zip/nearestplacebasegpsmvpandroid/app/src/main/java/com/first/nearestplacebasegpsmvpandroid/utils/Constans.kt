package com.first.nearestplacebasegpsmvpandroid.utils

class Constans {
    companion object {
        const val BASE_URL = "https://maps.googleapis.com/maps/api/place/"
        const val KEY_API = "AIzaSyDDQCAmS8_lRnbZtjRZBvItB1851LO__xA"
    }
}