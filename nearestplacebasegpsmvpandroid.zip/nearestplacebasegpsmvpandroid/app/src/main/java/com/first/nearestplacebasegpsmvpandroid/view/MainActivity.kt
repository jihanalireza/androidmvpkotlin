package com.first.nearestplacebasegpsmvpandroid.view

import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.widget.Toast
import com.first.nearestplacebasegpsmvpandroid.R
import com.first.nearestplacebasegpsmvpandroid.adapter.MyplaceRecyclerViewAdapter
import com.first.nearestplacebasegpsmvpandroid.model.ResultsItem
import com.first.nearestplacebasegpsmvpandroid.presenter.PlacePresenter
import com.first.nearestplacebasegpsmvpandroid.presenter.PlaceView
import com.first.nearestplacebasegpsmvpandroid.utils.GPSTracker
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(),PlaceView{

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val presenter =  PlacePresenter(this)
        val gps = GPSTracker(this)

        if(gps.checkPermission(this)){

            if(gps.canGetLocation()){
                Toast.makeText(this,"GPS ON",Toast.LENGTH_LONG).show()
            }
        }else{
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,android.Manifest.permission.ACCESS_COARSE_LOCATION),2)
            }
        }

        btnCari.setOnClickListener {
            val keyword =  keyword.text.toString()
           searchPlace(keyword)
        }

    }


    fun searchPlace(keyword: String) {
        val presenter =  PlacePresenter(this)
        val gps = GPSTracker(this)

        if(gps.canGetLocation()){
            val lat = gps.latitude
            val lon = gps.longitude

            val location = "$lat,$lon"
            presenter.loadData(location,keyword,"restaurant",getString(R.string.key_google))
        }
    }

    override fun onResult(data: List<ResultsItem>) {
        showData(data)
    }

    override fun onError(msg : String) {
        Toast.makeText(this,msg,Toast.LENGTH_LONG).show()
    }

    private fun showData(data: List<ResultsItem>) {
        recycleview.adapter = MyplaceRecyclerViewAdapter(data)
        recycleview.layoutManager = LinearLayoutManager(this)
    }
}
